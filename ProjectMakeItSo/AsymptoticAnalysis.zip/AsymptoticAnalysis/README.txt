1. Write an algorithm that takes an array of numbers as inputs and calculates the sum of those numbers​
    ​
2. Define the Time Complexity of that algorithm and determine what the lowest possible Time Complexity is for this problem​
    ​
3. Create a program where time complexity is (n^2) (be able to explain it)​
4. Create a program where time complexity is (log n) (be able to explain it)
