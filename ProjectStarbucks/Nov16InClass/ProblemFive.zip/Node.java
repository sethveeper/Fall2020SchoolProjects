
public class Node
{
	byte value;
	Node next;
	
    public Node(byte inValue)
    {
        value = inValue;
        next = null;
    }
    // End of constructor
    
    public void Add(byte inValue)
    {
        if(next == null)
            next = new Node(inValue);
        else
            next.Add(inValue);
    }
    // End of Add method
    
    public int Count()
    {
        int total = 1;
        if(next == null)
            return total;
        else
            return next.Count(total);
    }
    // End of Count default overload
    
    public int Count(int total)
    {
        total++;
        if(next == null)
            return total;
        else
            return next.Count(total);
    }
    // End of Count method 
}
// End of Main class 