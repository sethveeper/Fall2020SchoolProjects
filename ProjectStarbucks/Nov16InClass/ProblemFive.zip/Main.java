/******************************************************************************

Write a program that reads 5 scores from the user and determines 
how many scores are above or equal to the average, and how many 
scores are below the average.

Modify with the following:
- Read in an unspecified number of scores.
- Enter a negative number to signify the end of the input.

*******************************************************************************/

import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	    
	    byte[] aryScores = GetScores();
	    
	    System.out.println("Scores entered: ");
	    double sum = 0;
	    for(int i : aryScores)
	    {
	        sum += i;
	        System.out.print(i + " ");
	    }
	    double average = sum / aryScores.length;
	    // End of For loop (Counting)
	    
	    int above = 0, below = 0;
	    for(byte i : aryScores)
	    {
	        if(i >= average)
	            above++;
	        else
	            below++;
	    }
	    // End of For loop (Checking against average)
	    
	    System.out.println("\nThere are " + above + " scores at or above average.");
	    System.out.println("There are " + below + " scores below average.");
	    
	}
	// End of main method 
	
	public static byte[] GetScores()
	{
	    boolean exit = false;
	    
	    byte input = GetInput();
	    Node list = new Node(input);
	    
	    while(!exit)
	    {
	        input = GetInput();
	        if (input < 0)
	            exit = true;
	        else
	        {
	            System.out.println("Score entered!");
	            list.Add(input);
	        }
	        // End of If/Else (exit clause)
	    }
	    // End of While loop (assignment)
	    
	    int length = list.Count();
	    byte[] output = new byte[length];
	    while(length > 0)
	    {
	        length--;
	        output[length] = list.value;
	        list = list.next;
	    }
	    // End of While loop (reassignment)
	    
	    return output;
	}
	// End of GetScores method
	
	private static byte GetInput()
	{
	    Scanner scanner = new Scanner(System.in);
        int input;
        byte output;
        
        try 
        {
            System.out.println("Please enter a score between 0-125 (Or enter e negative number to exit):");
            input = scanner.nextInt();
        } 
        catch(Exception e) 
        {
            System.out.println("That is not a number!");
            input = GetInput();
        }
        // End of Try/Catch (Valid Input)
        
        if(input > 125)
        {
            System.out.println("That is too high! Scores must be lower than 126.");
            output = GetInput();
        }
        else
        {
            output = (byte)input;
        }
        // End if If/Else (score validation)
	    
	    return output;
	}
	// End of GetInput method
}
// End of Main class 