3. (Chapter 2) Write a program that prompts the user to enter the minutes (example:  1 billion), and displays the number of years and remaining days for the minutes. For simplicity, assume that a year has 365 days.

Here is a sample run:
Enter the number of minutes: 1000000000
1000000000 minutes is approximately 1902 years and 214 days