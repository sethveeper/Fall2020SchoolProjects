2. (Chapter 2) Write a program that reads in the radius and length of a cylinder and 
computes the area and volume using the following formulas:

area = radius * radius * p
volume = area * length

Here is a sample run:
Enter the radius and length of a cylinder: 5.5 12
The area is 95.0331
The volume is 1140.4

