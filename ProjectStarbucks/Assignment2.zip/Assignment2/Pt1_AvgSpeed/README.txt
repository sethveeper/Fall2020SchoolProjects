1. (Chapter 1) Assume that a runner runs 14 kilometers in 45 minutes and 30 seconds. 
Write a program that displays the average speed in miles per hour. 
(Note 1 mile is equal to 1.6 kilometers.)